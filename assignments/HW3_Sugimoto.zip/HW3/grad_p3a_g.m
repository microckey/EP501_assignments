function [fx,fy] = grad_p3a_g(x,y)

fx = x./2;
fy = 2*y;

end %function