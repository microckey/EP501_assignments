function [fx,fy] = grad_p3a_f(x,y)

fx = 2*x - 2;
fy = 2*y - y;

end %function