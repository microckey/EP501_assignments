function [gx,gy,gz] = grad_p3b_g(x,y,z)

gx = 2*x;
gy = -2*y;
gz = 4*z;

end %function