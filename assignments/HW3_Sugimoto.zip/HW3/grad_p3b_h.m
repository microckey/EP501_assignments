function [hx,hy,hz] = grad_p3b_h(x,y,z)

hx = 4*x;
hy = 2*y;
hz = -2*z;

end %function