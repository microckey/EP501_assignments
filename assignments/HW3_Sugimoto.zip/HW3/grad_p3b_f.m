function [fx,fy,fz] = grad_p3b_f(x,y,z)

fx = 2*x;
fy = 2*y;
fz = 2*z;

end %function