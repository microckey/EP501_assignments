function [i,j] = findij(xi,xprime,yi,yprime)

i = findi(xi,xprime);
j = findi(yi,yprime);

end % function