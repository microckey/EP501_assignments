% Midterm Problem 3 (a)

clear
clc
close all

%% Coefficients of the quadratic equation
A = [2;-6;4];

%% Solve for roots
x = solveqe(A)